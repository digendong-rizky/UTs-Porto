<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Portfolio - <?php echo e($mahasiswa->user->name); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'DejaVu Sans', 'Helvetica', Arial, sans-serif;
            font-size: 15px;
            line-height: 1.55;
            color: #111;
            padding: 28px 36px 32px;
        }
        .page { width: 100%; }
        .header {
            display: table;
            width: 100%;
            table-layout: fixed;
            margin-bottom: 18px;
        }
        .header-left {
            display: table-cell;
            width: 60%;
            vertical-align: top;
        }
        .header-right {
            display: table-cell;
            width: 40%;
            vertical-align: top;
            text-align: right;
        }
        .name {
            font-size: 29px;
            font-weight: 800;
            letter-spacing: 0.5px;
        }
        .role {
            margin-top: 6px;
            font-size: 15px;
            text-transform: uppercase;
            letter-spacing: 1.1px;
        }
        .contacts {
            text-align: left;
            font-size: 14px;
            line-height: 1.6;
            /* Kontak di sisi kanan header, tapi teks rata kiri */
            display: inline-block;
            width: 100%;
        }
        .contact-item {
            margin-bottom: 4px;
        }
        .contact-label {
            font-weight: 600;
            margin-right: 6px;
        }
        .contact-value {
            font-weight: 400;
        }
        .divider {
            border-top: 1px solid #000;
            margin: 10px 0 26px;
        }
        .section {
            margin-bottom: 36px;
        }
        .section-title {
            font-size: 21px; /* +2pt for section labels */
            font-weight: 800;
            letter-spacing: 0.8px;
            margin-bottom: 12px;
        }
        .block {
            margin-bottom: 14px;
        }
        .block-title {
            font-weight: 700;
            font-size: 16px;
            margin-bottom: 2px;
        }
        .meta {
            font-size: 14px;
            color: #333;
            margin-bottom: 6px;
        }
        .bullet {
            margin-left: 14px;
            font-size: 15px;
        }
        .grid-two {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px 28px;
        }
        .flex-two {
            display: table;
            width: 100%;
            table-layout: fixed;
            margin-bottom: 36px;
        }
        .side-section {
            margin-bottom: 36px;
        }
        .cert-col, .skill-col {
            display: table-cell;
            width: 50%;
            vertical-align: top;
            padding-right: 14px;
        }
        .skill-col {
            padding-right: 0;
            padding-left: 14px;
        }
        .label {
            font-weight: 700;
            font-size: 15px;
        }
        .small {
            font-size: 14px;
            color: #333;
        }
        .inline-skill { font-weight: 700; }
        .nowrap { white-space: nowrap; }
    </style>
</head>
<body>
<?php
    $portfolio = $portofolio;
    $experienceList = $portfolio?->experiences?->sortBy('urutan') ?? $mahasiswa->experiences ?? collect();
    $projectList = $portfolio?->projects?->sortBy('urutan') ?? $mahasiswa->projects ?? collect();
    $certificateList = $portfolio?->certificates?->sortBy('urutan') ?? $mahasiswa->certificates ?? collect();
    $skillList = $portfolio?->skills?->sortBy('urutan') ?? $mahasiswa->skills ?? collect();
    $roleTitle = $portfolio?->nama ?: ($portfolio?->bidang ? strtoupper($portfolio->bidang) : 'PORTFOLIO');
    $address = $mahasiswa->alamat ?? '';
    // language stored as text or json; normalize to collection
    $languageRaw = $portfolio?->language ?? null;
    if (is_string($languageRaw)) {
        $decoded = json_decode($languageRaw, true);
        $languageList = collect($decoded && is_array($decoded) ? $decoded : array_filter(array_map('trim', explode(',', $languageRaw))));
    } elseif (is_array($languageRaw)) {
        $languageList = collect($languageRaw);
    } else {
        $languageList = collect();
    }
?>

<div class="page">
    <header class="header">
        <div class="header-left">
            <div class="name"><?php echo e($mahasiswa->user->name); ?></div>
            <div class="role"><?php echo e($roleTitle); ?></div>
        </div>
        <div class="header-right">
            <div class="contacts">
                <?php if($mahasiswa->no_telp): ?>
                    <div class="contact-item">
                        <span class="contact-label">Phone:</span>
                        <span class="contact-value"><?php echo e($mahasiswa->no_telp); ?></span>
                    </div>
                <?php endif; ?>
                <?php if($mahasiswa->user->email): ?>
                    <div class="contact-item">
                        <span class="contact-label">Email:</span>
                        <span class="contact-value"><?php echo e($mahasiswa->user->email); ?></span>
                    </div>
                <?php endif; ?>
                <?php if($address): ?>
                    <div class="contact-item">
                        <span class="contact-label">Address:</span>
                        <span class="contact-value"><?php echo e($address); ?></span>
                    </div>
                <?php endif; ?>
                <?php if($mahasiswa->github): ?>
                    <div class="contact-item">
                        <span class="contact-label">Website:</span>
                        <span class="contact-value"><?php echo e($mahasiswa->github); ?></span>
                    </div>
                <?php endif; ?>
                <?php if($mahasiswa->linkedin): ?>
                    <div class="contact-item">
                        <span class="contact-label">LinkedIn:</span>
                        <span class="contact-value"><?php echo e($mahasiswa->linkedin); ?></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="divider"></div>

    
    <?php if($experienceList->count()): ?>
    <section class="section">
        <div class="section-title">EXPERIENCE</div>
        <?php $__currentLoopData = $experienceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $start = $exp->tanggal_mulai ? \Carbon\Carbon::parse($exp->tanggal_mulai)->format('M Y') : null;
                $end = $exp->masih_berlangsung ? 'Present' : ($exp->tanggal_selesai ? \Carbon\Carbon::parse($exp->tanggal_selesai)->format('M Y') : null);
            ?>
            <div class="block">
                <div class="block-title"><?php echo e($exp->judul); ?></div>
                <div class="meta">
                    <?php echo e($exp->perusahaan ?? ''); ?>

                    <?php if($start || $end): ?>
                        · <?php echo e(trim($start.' - '.$end, ' -')); ?>

                    <?php endif; ?>
                    <?php if($exp->tipe): ?>
                        · <?php echo e(ucfirst($exp->tipe)); ?>

                    <?php endif; ?>
                </div>
                <?php if($exp->deskripsi): ?>
                    <div class="bullet">• <?php echo e($exp->deskripsi); ?></div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    <?php endif; ?>

    
    <?php if($mahasiswa->universitas || $mahasiswa->fakultas || $mahasiswa->jurusan): ?>
    <section class="section">
        <div class="section-title">EDUCATION</div>
        <div class="block">
            <div class="block-title"><?php echo e($mahasiswa->universitas ?? ''); ?></div>
            <div class="meta">
                <?php echo e($mahasiswa->fakultas ? $mahasiswa->fakultas.' - ' : ''); ?><?php echo e($mahasiswa->jurusan ?? ''); ?>

            </div>
        </div>
    </section>
    <?php endif; ?>

    
    <?php if($languageList->count()): ?>
    <section class="section">
        <div class="section-title">LANGUAGES</div>
        <div class="grid-two">
            <?php $__currentLoopData = $languageList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="small"><?php echo e($lang); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <?php endif; ?>

    
    <?php if($certificateList->count() || $skillList->count()): ?>
    <div class="flex-two">
        
        <div class="cert-col">
            <?php if($certificateList->count()): ?>
            <div class="section-title">CERTIFICATES</div>
            <?php $__currentLoopData = $certificateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="block">
                    <div class="block-title"><?php echo e($cert->nama); ?></div>
                    <div class="meta">
                        <?php echo e($cert->penerbit ?? ''); ?>

                        <?php if($cert->tanggal_terbit): ?>
                            • <?php echo e(\Carbon\Carbon::parse($cert->tanggal_terbit)->format('M Y')); ?>

                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>

        
        <div class="skill-col">
            <?php if($skillList->count()): ?>
            <div class="section-title">SKILLS</div>
            <?php $__currentLoopData = $skillList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="small" style="margin-bottom: 8px;"><span class="inline-skill"><?php echo e($skill->nama); ?></span> (<?php echo e(ucfirst($skill->level)); ?>)</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
</body>
</html>


<?php /**PATH C:\laragon\www\PortoConnect-beta\backend\resources\views/portfolio-pdf.blade.php ENDPATH**/ ?>